package br.com.freemarket.produtos;

public class Roupa extends Produto{
    private String marca;
    private char tam;
    private String cor;

    public Roupa(long id, String nome, String marca, char tam, String cor, double preço,String descricao, int quant) {
        super(id, nome, preço, descricao, quant);
        this.marca = marca;
        this.cor = cor ;
        this.tam = tam;
    }
}
