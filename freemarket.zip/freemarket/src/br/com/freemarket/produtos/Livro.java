package br.com.freemarket.produtos;

public class Livro extends Produto{
   private String autor;

    public Livro(long id, String nome, String autor, double preço,String descricao, int quant) {
        super(id, nome, preço, descricao, quant);
        this.autor = autor;
    }

}