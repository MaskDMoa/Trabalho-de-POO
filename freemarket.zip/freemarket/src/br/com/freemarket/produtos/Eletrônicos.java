package br.com.freemarket.produtos;

public class Eletrônicos extends Produto {
    private String marca;


    public Eletrônicos(long id, String nome, String marca, double preço,String descricao, int quant) {
        super(id, nome, preço, descricao, quant);
        this.marca = marca;
    }
}
