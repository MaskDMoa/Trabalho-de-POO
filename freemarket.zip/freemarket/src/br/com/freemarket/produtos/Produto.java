package br.com.freemarket.produtos;

public class Produto {
   private long id; // num p/ identificar o produto
   private String nome;
   private String descricao; // descrição
   private double preço;
   private int quant; // quantidade em estoque

    public Produto(long id, String nome, double preço, String descricao, int quant) {
        this.nome = nome;
        this.id = id;
        this.preço = preço;
        this.quant = quant;
        this.descricao = descricao;
    }

    public double getPreço() {
        return preço;
    }

    public String getNome() {
        return nome;
    }
}
