package br.com.freemarket.pagamento;

public class PagamentoException extends RuntimeException {
    public PagamentoException(String message) {

      super(message);
    }
}
