package br.com.freemarket.pagamento;

import br.com.freemarket.Usuario.Cliente;

public class Pagamento implements PagamentoSaldo {

    private Cliente cliente;

    public Pagamento(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public boolean pagar(double valor) throws PagamentoException {

        if (valor <= 0) {
            throw new PagamentoException("Valor de compra inválido.");
        }

        if (cliente.getSaldo() < valor) {
            throw new PagamentoException("Saldo insuficiente.");
        }

        cliente.setSaldo(cliente.getSaldo() - valor);
        return true;
    }
}

