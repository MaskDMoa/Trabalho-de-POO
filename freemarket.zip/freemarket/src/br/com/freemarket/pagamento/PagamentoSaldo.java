package br.com.freemarket.pagamento;

public interface PagamentoSaldo {
        boolean pagar(double valor) throws PagamentoException;

}
