package br.com.freemarket.Usuario;

public class Usuario {
    private String id;
    private String nome;
    private String cpf;

    public Usuario(String id, String nome, String cpf) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
    }
}
