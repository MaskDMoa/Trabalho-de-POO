package br.com.freemarket.Usuario;
import br.com.freemarket.produtos.Produto;
public class Cliente extends Usuario{
    private double saldo;
    public Carrinho carrinho;
    public Cliente(double saldo, String id, String nome, String cpf) {
        super ( id, nome, cpf);
        this.saldo = saldo;
        carrinho = new Carrinho();
    }
    public void additem(Produto item,Carrinho carrinho){
        carrinho.ListadeProduto.add(item);
        System.out.println("Adicionado ao carrinho"+ item); }
    public void remove_item(Produto item,Carrinho carrinho){
        carrinho.ListadeProduto.remove(item);
        System.out.println("Removido do carrinho"+ item); }
    public void concluirpedido(){
        System.out.println( "Total da compra R$" + carrinho.total());
        System.out.println("Prosseguindo para pagamento");
        carrinho.processaPagamento(this);
    }
    public double getSaldo() {
        return saldo; }
    public void setSaldo(double saldo) {
        this.saldo = saldo; }

    public Carrinho getCarrinho() {
        return carrinho;
    }

}
