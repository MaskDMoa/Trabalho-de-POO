package br.com.freemarket.Usuario;

import br.com.freemarket.pagamento.Pagamento;
import br.com.freemarket.pagamento.PagamentoException;
import br.com.freemarket.produtos.Produto;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {

    List <Produto> ListadeProduto = new ArrayList<Produto>();

    public double total(){
        double soma = 0;
        for (Produto item : ListadeProduto){
            soma += item.getPreço();
        }
        return soma;
    }

    public void processaPagamento(Cliente cliente){

        double valorCompra = total();

        // Pagamento precisa do cliente para acessar saldo
        Pagamento pagamento = new Pagamento(cliente);

        try {
            boolean aprovado = pagamento.pagar(valorCompra);

            if (aprovado) {
                System.out.println("Pagamento aprovado!");
            }

        } catch (PagamentoException e) {
            System.out.println("Erro no pagamento: " + e.getMessage());
        }
    }
}
