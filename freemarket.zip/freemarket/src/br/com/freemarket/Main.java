package br.com.freemarket;

import br.com.freemarket.Usuario.Cliente;

public class Main {
    public static void main(String[] args) {
        Cliente c1 = new Cliente(200, "1234", "Lucca", "0987654");
        c1.concluirpedido();
    }
}
